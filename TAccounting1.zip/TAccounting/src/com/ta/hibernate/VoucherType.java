package com.ta.hibernate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="Voucher_Type")

public class VoucherType {
@Id 
@GeneratedValue

int id;

String vtypeName;
int status;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getVtypeName() {
	return vtypeName;
}
public void setVtypeName(String vtypeName) {
	this.vtypeName = vtypeName;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}

}
