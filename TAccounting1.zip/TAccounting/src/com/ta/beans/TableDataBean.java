package com.ta.beans;

import java.util.List;

public class TableDataBean
{
	List<List<String>> tableData;

	public List<List<String>> getTableData() {
		return tableData;
	}

	public void setTableData(List<List<String>> tableData) {
		this.tableData = tableData;
	}

}
