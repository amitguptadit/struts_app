package com.ta.Actions;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.ActionSupport;
import com.ta.Repo.LedgerRepo;
import com.ta.hibernate.Login;
import com.ta.hibernate.utility.HibernateUtil;

public class LoginAction extends ActionSupport implements ServletRequestAware, SessionAware, ServletResponseAware 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name = "";
    private String password = "";
    HttpServletRequest request;
	HttpServletResponse response;
	Map m;
    public String getName() 
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	
	public HashMap<String, String> getLogin(String email, String password) 
	{
		HashMap<String, String> result=null;
		HashMap<String, String> resultMap = new HashMap();

		 System.out.println("[getLogin-->#"+email+"#password#"+password+"]");
       /* Session session = null;
        Transaction txn = null;

       
        try 
        {
            session = HibernateUtil.getSessionFactory().openSession();
            txn = session.beginTransaction();
            session.getTransaction().commit();
            Query qry=session.createQuery("from Login where name=?,password=?");
            qry.setString(0,getName());
            qry.setString(1,getPassword());
            Login lg=(Login) qry.uniqueResult();
            System.out.println("[Get Result from Login"+lg+" ]");
    		session.close();
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }*/
		return result;
	}
	public void validate()
	{

        System.out.println(">>>>>>>>>>>>>>>>>" + getName());
        System.out.println(">>>>>>>>>>>>>>>>>" + getPassword());
        if (getName().length() == 0)
        {
            addFieldError("userName", "Please enter valid username");
            System.out.println(">>>>>>>> HSHSHSHSH >>>>>>>>>");
        }
        if (getPassword().length() == 0)
        {
            addFieldError("password", getText("Please enter valid password"));
        }
    }
	public String execute() throws Exception 
	{
		String resultString = "fail";
		Login logins=null;
		try 
		{
			LedgerRepo repo=new LedgerRepo();
			logins=repo.getLogin(name,password);
			if(logins!=null)
			{
				resultString = "success";
			}
			request.getSession().setAttribute("userAccount", logins);
			//String ret=(String)request.getSession().getAttribute("userAccount");
			 
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		//return resultString;
		return resultString;
	}
	public void setSession(Map map)
	{
        this.m = map;
    }
	public Map getM() 
	{
		return m;
	}
	public void setM(Map map)
	{
		this.m = map;
	}

	@Override
	public void setServletResponse(HttpServletResponse hsr)
	{
		// TODO Auto-generated method stub
		this.response = hsr;
		
	}

	@Override
	public void setServletRequest(HttpServletRequest hsr)
	{
		this.request = hsr;
		// TODO Auto-generated method stub
		
	}

}
