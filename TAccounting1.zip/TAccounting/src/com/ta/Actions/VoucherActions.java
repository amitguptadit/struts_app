package com.ta.Actions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.ta.Repo.LedgerRepo;
import com.ta.beans.VoucherDtlBean;
import com.ta.hibernate.AccountDetails;
import com.ta.hibernate.EntrySet;
import com.ta.hibernate.EntryTypeDetails;
import com.ta.hibernate.Voucher;
import com.ta.hibernate.VoucherType;
import com.ta.hibernate.utility.HibernateUtil;

public class VoucherActions extends ActionSupport implements
		ServletRequestAware {
	HttpServletRequest req;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Integer vchId;
	List<EntryTypeDetails> entryList;
	List<AccountDetails> accountList;
	List<Voucher> voucherList;
	List<VoucherDtlBean> vchBeanList;
	VoucherDtlBean voucherDetail;

	public VoucherDtlBean getVoucherDetail() {
		return voucherDetail;
	}

	public void setVoucherDetail(VoucherDtlBean voucherDetail) {
		this.voucherDetail = voucherDetail;
	}

	String vchType;
	String abc;
	String[] type;
	String[] particular, entryCreditAmount;
	String[] entryDebitAmount;

	public Integer getVchId() {
		return vchId;
	}

	public void setVchId(Integer vchId) {
		this.vchId = vchId;
	}

	public List<VoucherDtlBean> getVchBeanList() {
		return vchBeanList;
	}

	public void setVchBeanList(List<VoucherDtlBean> vchBeanList) {
		this.vchBeanList = vchBeanList;
	}

	public List<Voucher> getVoucherList() {
		return voucherList;
	}

	public void setVoucherList(List<Voucher> voucherList) {
		this.voucherList = voucherList;
	}

	public String getVchType() {
		return vchType;
	}

	public void setVchType(String vchType) {
		this.vchType = vchType;
	}

	public String[] getType() {
		return type;
	}

	public void setType(String[] type) {
		this.type = type;
	}

	public String[] getParticular() {
		return particular;
	}

	public void setParticular(String[] particular) {
		this.particular = particular;
	}

	public String[] getEntryCreditAmount() {
		return entryCreditAmount;
	}

	public void setEntryCreditAmount(String[] entryCreditAmount) {
		this.entryCreditAmount = entryCreditAmount;
	}

	public String[] getEntryDebitAmount() {
		return entryDebitAmount;
	}

	public void setEntryDebitAmount(String[] entryDebitAmount) {
		this.entryDebitAmount = entryDebitAmount;
	}

	public List<AccountDetails> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<AccountDetails> accountList) {
		this.accountList = accountList;
	}

	public List<EntryTypeDetails> getEntryList() {
		return entryList;
	}

	public void setEntryList(List<EntryTypeDetails> entryList) {
		this.entryList = entryList;
	}

	public HttpServletRequest getReq() {
		return req;
	}

	public void setReq(HttpServletRequest req) {
		this.req = req;
	}

	public String getAbc() {
		return abc;
	}

	public void setAbc(String abc) {
		this.abc = abc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String createVoucherType() {
		try {
			SessionFactory sFactory = HibernateUtil.getSessionFactory();
			Session session = sFactory.openSession();
			session.clear();
			session.beginTransaction();
			VoucherType voucherType = new VoucherType();
			System.out.println(req.getParameter("vType") + "vtype= " + vchType);
			vchType = (vchType == null ? req.getParameter("vType") : vchType);
			voucherType.setVtypeName(vchType);
			voucherType.setStatus(0);
			session.save(voucherType);

			session.getTransaction().commit();
			session.flush();
			session.close();
			return "success";
		} catch (HibernateException he) {
			he.printStackTrace();
		}

		return "fail";
	}

	public String createVoucherForm() {
		if (entryList != null)
			entryList.clear();
		if (accountList != null)
			accountList.clear();
		LedgerRepo legRepo = new LedgerRepo();
		setEntryList(legRepo.getEntryKeyList());
		setAccountList(legRepo.getAccountDetails());
		return Action.SUCCESS;
	}

	public String getVoucherDetails()
	{//getVoucherDetails
		//VoucherDtlBean 
		vchBeanList=new ArrayList<VoucherDtlBean>();
		voucherDetail=new VoucherDtlBean();
		LedgerRepo repo=new LedgerRepo();
		System.out.println("here vchid="+vchId);
		List<EntrySet> entryList=repo.getVoucherDetailsForVoucherId(vchId);
		voucherDetail.setVchEntryList(entryList);
		if(entryList.size()>0)
		{
			Voucher vch=entryList.get(0).getvId();
			voucherDetail.setAmount(""+vch.getAmount());
			System.out.println("voucherDetail---->"+voucherDetail.getAmount());
			voucherDetail.setDate_time(vch.getDatetime());
			voucherDetail.setId(""+vchId);
			voucherDetail.setNarration(vch.getNarration());
			voucherDetail.setType(vch.getvType().getVtypeName());
		}
		else
		{
			voucherDetail=null;
		}
		
		vchBeanList.add(voucherDetail);
		return Action.SUCCESS;
	}
	public String saveVoucher() {
		try {
			System.out.println("fghjjdfghjsdyuuvjhbkjlj");
			// SessionFactory sFactory= HibernateUtil.getSessionFactory();
			// Session session=sFactory.openSession();
			// session.beginTransaction();
			Voucher voucher = new Voucher();
			System.out.println("entryList-->" + vchType);
			// String[] list1=req.getParameterValues("entryType");
			// String[] list2=req.getParameterValues("particular");
			// String[] list3=req.getParameterValues("entryCreditAmount");
			// String[] list4=req.getParameterValues("entryDebitAmount");
			//
			// System.out.println("list1"+list1);
			// System.out.println("list2"+list2);
			// System.out.println("list3"+list3);
			// System.out.println("list4"+list4);
			try {
				SessionFactory sFactory = HibernateUtil.getSessionFactory();
				Session session = sFactory.openSession();
				session.clear();
				session.beginTransaction();

				VoucherType vtType = new VoucherType();
				int id = Integer.parseInt(vchType);
				vtType.setId(id);
				voucher.setvType(vtType);
				voucher.setStatus(0);
				Float crAmount = 0F;
				Float drAmount = 0F;
				List<EntrySet> esList = new ArrayList<EntrySet>();
				for (int i = 0; i < entryDebitAmount.length; i++) {
					EntrySet es = new EntrySet();
					EntryTypeDetails etd = new EntryTypeDetails();
					AccountDetails part = new AccountDetails();
					part.setId(Integer.parseInt(particular[i]));
					etd.setId(Integer.parseInt(type[i]));
					es.setEntryType(etd);
					es.setParticularId(part);
					float curAmount = 0;

					if (type[i].equals("2")) {
						curAmount = Float.parseFloat(entryDebitAmount[i]);
						crAmount += curAmount;
					} else {
						curAmount = Float.parseFloat(entryCreditAmount[i]);
						drAmount += curAmount;
					}
					es.setAmount(curAmount);
					// es.setAmount(Float.parseFloat(entryDebitAmount[i]));

					// esList.add(es);
					es.setvId(voucher);
					session.save(es);

				}
				if (!drAmount.equals(crAmount)) {
					session.getTransaction().rollback();
					session.clear();
					System.out.println(drAmount
							+ "invalid voucher entries cr!=dr " + crAmount);
				}

				else {
					voucher.setAmount(drAmount);
					Date dt = new Date();
					DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
					voucher.setDatetime(df.format(dt));
					session.save(voucher);
					session.getTransaction().commit();
					session.flush();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			// System.out.println(t);
			System.out.println(req.getParameterValues("entryCreditAmount")
					.toString() + "abc= " + entryCreditAmount);
			// TODO: hadle req here
		} catch (Exception ex) {
			ex.printStackTrace();
			return Action.ERROR;
		}
		LedgerRepo repo = new LedgerRepo();
		setVoucherList(repo.getVouchersForRole(-1));
		vchBeanList = new ArrayList<VoucherDtlBean>();
		for (Voucher vch : getVoucherList()) {
			VoucherDtlBean vchBean = new VoucherDtlBean();
			vchBean.setAmount("" + vch.getAmount());
			vchBean.setDate_time("" + vch.getDatetime());
			vchBean.setId("" + vch.getvId());
			vchBean.setNarration(vch.getNarration());
			vchBean.setType("" + vch.getvType().getVtypeName());
			vchBeanList.add(vchBean);
			System.out.println(vchBean.getDate_time() + "type " + vch.getvId()
					+ " vtype" + vch.getvType() + " nar=" + vch.getNarration());
		}
		return Action.SUCCESS;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {

		req = request;
	}

	public String displayVouchers() {
		LedgerRepo repo = new LedgerRepo();
		setVoucherList(repo.getVouchersForRole(-1));
		vchBeanList = new ArrayList<VoucherDtlBean>();
		for (Voucher vch : getVoucherList()) {
			VoucherDtlBean vchBean = new VoucherDtlBean();
			vchBean.setAmount("" + vch.getAmount());
			vchBean.setDate_time("" + vch.getDatetime());
			vchBean.setId("" + vch.getvId());
			vchBean.setNarration(vch.getNarration());
			vchBean.setType("" + vch.getvType().getVtypeName());
			vchBeanList.add(vchBean);
			System.out.println(vchBean.getDate_time() + "type " + vch.getvId()
					+ " vtype" + vch.getvType() + " nar=" + vch.getNarration());

		}
		return Action.SUCCESS;
	}

}
