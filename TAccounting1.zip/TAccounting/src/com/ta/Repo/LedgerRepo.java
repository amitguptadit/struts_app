package com.ta.Repo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ta.hibernate.AccountDetails;
import com.ta.hibernate.AccountTypeDetails;
import com.ta.hibernate.EntrySet;
import com.ta.hibernate.EntryTypeDetails;
import com.ta.hibernate.Login;
import com.ta.hibernate.Voucher;
import com.ta.hibernate.VoucherType;
import com.ta.hibernate.utility.HibernateUtil;

public class LedgerRepo {
	private SessionFactory sFactory;

	// private Session session;

	public LedgerRepo() {
		sFactory = new Configuration().configure().buildSessionFactory();
	}

	public List<EntrySet> getVoucherDetailsForVoucherId(Integer vId){
	List<EntrySet> entryList=null;
		Session session=null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			entryList = session.createQuery( "from EntrySet es where es.vId ="+vId).list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return entryList;
	}

	public List<AccountTypeDetails> getAllAccountType() {
		List<AccountTypeDetails> allAccountTypeList = null;
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			allAccountTypeList = session.createQuery("from AccountTypeDetails")
					.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return allAccountTypeList;
	}

	public List<VoucherType> getAllVoucherType() {
		List<VoucherType> allVType = null;
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			allVType = session.createQuery("from VoucherType where status=0")
					.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return allVType;
	}

	public List<String> getEntryValueList() {
		List<String> entryList = new ArrayList<String>();
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			Query qry = session
					.createQuery("select entryTypeName from EntryTypeDetails order by id");
			entryList = qry.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..2");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return entryList;
	}

	public List<EntryTypeDetails> getEntryKeyList() {
		List<EntryTypeDetails> entryKeyList = new ArrayList<EntryTypeDetails>();
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			Query qry = session
					.createQuery("from EntryTypeDetails order by id");
			entryKeyList = qry.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..3");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return entryKeyList;
	}

	public List<AccountDetails> getAccountDetails() {
		List<AccountDetails> list = new ArrayList<AccountDetails>();
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from AccountDetails order by id");
			list = qry.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..3");
			he.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}

	public List<Voucher> getVouchersForRole(Integer role) {
		List<Voucher> voucherList = null;
		Session session = null;
		try {
			session = sFactory.openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from Voucher order by id");
			voucherList = qry.list();
			session.getTransaction().commit();
		} catch (HibernateException he) {
			System.out.println("here..3");
			he.printStackTrace();
		} finally {
			session.close();
		}

		return voucherList;
	}

	public Login getLogin(String email, String password) {
		String result = null;
		Session session = null;
		Transaction txn = null;
		Login logins = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			txn = session.beginTransaction();

			// Query
			// qry=session.createQuery("from Login where name=? and password=?");
			System.out.println("[LoginRepo-->email:" + email + ",Pwd:"
					+ password + " ]");
			Query qry = session.createQuery("from Login where name='" + email
					+ "' and password='" + password + "'");
			// qry.setString(0,email);
			// qry.setString(1,password);
			logins = (Login) qry.uniqueResult();
			System.out.println("[Get Result from Login" + logins + " ]");
			if (logins == null) {
				result = "fail";
			} else {
				result = "success";
			}
			txn.commit();
			// session.getTransaction().commit();

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			session.close();
		}

		// return result;
		return logins;
	}
}
