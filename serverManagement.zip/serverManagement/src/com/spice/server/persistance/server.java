package com.spice.server.persistance;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class server 
{
	@Id
	@GeneratedValue
	int server_id;
	String date_time,local_ip,public_ip,server_model,server_type,serial_no,os,location,service,owner,server_usr,server_pwd,db_type,db_usr,db_pwd,updateby_empName;
	int live_status;
	public int getServer_id() 
	{
		return server_id;
	}
	public void setServer_id(int server_id) {
		this.server_id = server_id;
	}
	public String getDate_time() {
		return date_time;
	}
	public void setDate_time(String date_time) {
		this.date_time = date_time;
	}
	public String getLocal_ip() {
		return local_ip;
	}
	public void setLocal_ip(String local_ip) {
		this.local_ip = local_ip;
	}
	public String getPublic_ip() {
		return public_ip;
	}
	public void setPublic_ip(String public_ip) {
		this.public_ip = public_ip;
	}
	public String getServer_model() {
		return server_model;
	}
	public void setServer_model(String server_model) {
		this.server_model = server_model;
	}
	public String getServer_type() {
		return server_type;
	}
	public void setServer_type(String server_type) {
		this.server_type = server_type;
	}
	public String getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(String serial_no) {
		this.serial_no = serial_no;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getServer_usr() {
		return server_usr;
	}
	public void setServer_usr(String server_usr) {
		this.server_usr = server_usr;
	}
	public String getServer_pwd() {
		return server_pwd;
	}
	public void setServer_pwd(String server_pwd) {
		this.server_pwd = server_pwd;
	}
	public String getDb_type() {
		return db_type;
	}
	public void setDb_type(String db_type) {
		this.db_type = db_type;
	}
	public String getDb_usr() {
		return db_usr;
	}
	public void setDb_usr(String db_usr) {
		this.db_usr = db_usr;
	}
	public String getDb_pwd() {
		return db_pwd;
	}
	public void setDb_pwd(String db_pwd) {
		this.db_pwd = db_pwd;
	}
	public String getUpdateby_empName() {
		return updateby_empName;
	}
	public void setUpdateby_empName(String updateby_empName) {
		this.updateby_empName = updateby_empName;
	}
	public int getLive_status() {
		return live_status;
	}
	public void setLive_status(int live_status) {
		this.live_status = live_status;
	}
}
