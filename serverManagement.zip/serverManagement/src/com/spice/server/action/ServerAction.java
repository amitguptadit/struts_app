package com.spice.server.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.opensymphony.xwork2.ActionSupport;
import com.spice.server.hb.txn.ProcessReq;
import com.spice.server.persistance.server;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
public class ServerAction extends ActionSupport implements ServletRequestAware
{
	//implements ServletRequestAware, SessionAware, ServletResponseAware
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	HttpServletRequest request;
	List<server> serverSummary=new ArrayList<server>();
	
	String local_ip,public_ip,server_model,server_type,serial_no,os,location,service,owner,server_usr,server_pwd,db_type,db_usr,db_pwd,updateby_empName;
	int live_status;
	Map m;
	public void setSession(Map map)
	{
        this.m = map;
    }
	public Map getM() 
	{
		return m;
	}
	public void setM(Map map)
	{
		this.m = map;
	}
	public String getLocal_ip() {
		return local_ip;
	}
	public void setLocal_ip(String local_ip) {
		this.local_ip = local_ip;
	}
	public String getPublic_ip() {
		return public_ip;
	}
	public void setPublic_ip(String public_ip) {
		this.public_ip = public_ip;
	}
	public String getServer_model() {
		return server_model;
	}
	public void setServer_model(String server_model) {
		this.server_model = server_model;
	}
	public String getServer_type() {
		return server_type;
	}
	public void setServer_type(String server_type) {
		this.server_type = server_type;
	}
	public String getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(String serial_no) {
		this.serial_no = serial_no;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getServer_usr() {
		return server_usr;
	}
	public void setServer_usr(String server_usr) {
		this.server_usr = server_usr;
	}
	public String getServer_pwd() {
		return server_pwd;
	}
	public void setServer_pwd(String server_pwd) {
		this.server_pwd = server_pwd;
	}
	public String getDb_type() {
		return db_type;
	}
	public void setDb_type(String db_type) {
		this.db_type = db_type;
	}
	public String getDb_usr() {
		return db_usr;
	}
	public void setDb_usr(String db_usr) {
		this.db_usr = db_usr;
	}
	public String getDb_pwd() {
		return db_pwd;
	}
	public void setDb_pwd(String db_pwd) {
		this.db_pwd = db_pwd;
	}
	public String getUpdateby_empName() {
		return updateby_empName;
	}
	public void setUpdateby_empName(String updateby_empName) {
		this.updateby_empName = updateby_empName;
	}
	public int getLive_status() {
		return live_status;
	}
	public void setLive_status(int live_status)
	{
		this.live_status = live_status;
	}
	public List<server> getServerSummary() 
	{
		return serverSummary;
	}
	public void setServerSummary(List<server> serverSummary)
	{
		this.serverSummary = serverSummary;
	}
	public String getSummary()
	{
		try
		{
			ProcessReq req=new ProcessReq();
			//serverSummary=req.serverSummary();	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return SUCCESS;
	}
	public String addServer()
	{
	//String local_ip,public_ip,server_model,server_type,
	//serial_no,os,location,service,owner,server_usr,server_pwd,db_type,db_usr,db_pwd,updateby_empName;
	//int live_status;
			
		String retstr="fail";
		//String addServer(HashMap<String,String> mp)
		//HashMap<String>,<String> adMap=new HashMap<String>,<String>();
		HashMap<String, String> addMap=new HashMap<String, String>();
		try
		{
			
			//request.getSession().setAttribute("serverId", "676767"); 
			//String out=(String)request.getSession().getAttribute("serverId"); 
			//${serverId}
			addMap.put("local_ip",local_ip);
			addMap.put("public_ip", public_ip);
			addMap.put("server_model",server_model);
			addMap.put("server_type",server_type);
			addMap.put("serial_no",serial_no);
			addMap.put("os",os);
			addMap.put("location",location);
			addMap.put("service",service);
			addMap.put("owner",owner);
			addMap.put("server_usr",server_usr);
			addMap.put("server_pwd",server_pwd);
			addMap.put("db_type",db_type);
			addMap.put("db_usr",db_usr);
			addMap.put("db_pwd",db_pwd);
			addMap.put("updateby_empName",updateby_empName);
			addMap.put("live_status",Integer.toString(live_status));
			//live_status
			ProcessReq req=new ProcessReq();
			retstr=req.addServer(addMap);
			System.out.println("[ServerAction-->local_ip:"+local_ip+"#public_ip:"+public_ip+"#server_model:"+server_model+"#server_type:"+server_type+"#serial_no:"+serial_no+"	]");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return retstr;
	}
	
	@Override
	public void validate()
	{
		try
		{
			ProcessReq req=new ProcessReq();
			if(req.checkServer(local_ip,0)!=null)
			{
				addFieldError("local_ip", "local_ip Server allready exists,Pls go to in update menu");
				 System.out.println(">>>>>>>> local_ip Server allready exists  >>>>>>>>>");
			}
			if(req.checkServer(public_ip,1)!=null)
			{
				addFieldError("public_ip", "Server allready exists,Pls go to in update menu");
				 System.out.println(">>>>>>>>public_ip Server allready exists  >>>>>>>>>");
			}			
		}
		catch(Exception ex)
		{
			System.out.println("[Exception-->#ServerAction#validate()#Ex"+ex);
			ex.printStackTrace();
		}
	}
	@Override
	public void setServletRequest(HttpServletRequest req)
	{
		// TODO Auto-generated method stub
		this.request=req;
		
	}

}
