package com.spice.server.interceptor;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import java.util.*;
import java.util.logging.LogManager;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;

public class SessInter implements Interceptor,ServletRequestAware  {
    //static Logger log = Logger.getLogger( SessInter.class.getName());
    public SessInter() {
       // log.info("[ INTERCEPTOR ] constructor");
        System.out.println("[ INTERCEPTOR ] constructor");
    }

    @Override
    public void destroy() {
        System.out.println("[ INTERCEPTOR ] destroy");
        //log.info("[ INTERCEPTOR ] destroy");
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void init() {
       // log.info("[ INTERCEPTOR ] init");
        System.out.println("[ INTERCEPTOR ] init");
      // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String intercept(ActionInvocation actionInvocation) throws Exception {

                ActionContext context = actionInvocation.getInvocationContext();
                                Map<String, Object> sessionMap = context.getSession();
               // log.info("[ INTERCEPTOR ]"+sessionMap.get("flag"));
               // System.out.println("[ INTERCEPTOR ]"+sessionMap.get("flag"));
                                if(sessionMap == null || sessionMap.isEmpty() || sessionMap.get("flag")==null) {
                                  //log.info("[ INTERCEPTOR ] session expired.");
                                    System.out.println("[ INTERCEPTOR ] session expired.");
                                  return "sessionexpired";
                                }
             
                                String actionResult = actionInvocation.invoke();
                                System.out.println("actionResult"+actionResult);
                                return actionResult;
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    HttpServletRequest request;
    public void setServletRequest(HttpServletRequest hsr) {
        this.request=hsr;
    }
}