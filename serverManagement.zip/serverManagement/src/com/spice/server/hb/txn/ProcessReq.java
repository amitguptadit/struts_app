package com.spice.server.hb.txn;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.hibernate.Query;
import org.hibernate.Session;

import com.spice.server.persistance.server;
import com.spice.server.utility.HibernateUtil;
public class ProcessReq
{
	public ArrayList<server> serverSummary(int serverID)
	{
		Session session = null;
		ArrayList<server> serverSummaryList=null;
		try
		{
		
			Query qry=null;
			session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			
			if(serverID==0)
			{	
				qry=session.createQuery("from server");
			}
			else
			{
				qry=session.createQuery("from server where server_id="+serverID);
				
				
			}
			serverSummaryList=(ArrayList<server>)qry.list();
			session.flush();
			session.close();
		}
		catch(Exception ex)
		{
			System.out.println("[Exception#ProcessReq#serverSummary():"+ex+"]");
			ex.printStackTrace();
		}		
		return serverSummaryList;		
	}//ArrayList<server> serverSummary(int serverID)
	public String addServer(HashMap<String,String> mp)
	{
		String retstr=null;
		try
		{
				DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd"); //"yyyy/MM/dd HH:mm:ss"
				Date date = new Date();
				//addMap.put("local_ip",local_ip);
				String date_time=dateFormat.format(date);
				Session session=null;
				String local_ip=(mp.get("local_ip")!=null?mp.get("local_ip"):"null");
				String public_ip=(mp.get("public_ip")!=null?mp.get("public_ip"):"null");
				String server_model=(mp.get("server_model")!=null?mp.get("server_model"):"null");
				String server_type=(mp.get("server_type")!=null?mp.get("server_type"):"null");
				String serial_no=(mp.get("serial_no")!=null?mp.get("serial_no"):"null");
				String os=(mp.get("os")!=null?mp.get("os"):"null");
				String location=(mp.get("location")!=null?mp.get("location"):"null");
				String service=(mp.get("service")!=null?mp.get("service"):"null");
				String owner=(mp.get("owner")!=null?mp.get("owner"):"null");
				String server_usr=(mp.get("server_usr")!=null?mp.get("server_usr"):"null");
				String server_pwd=(mp.get("server_pwd")!=null?mp.get("server_pwd"):"null");
				String db_type=(mp.get("db_type")!=null?mp.get("db_type"):"null");
				String db_usr=(mp.get("db_usr")!=null?mp.get("db_usr"):"null");
				String db_pwd=(mp.get("db_pwd")!=null?mp.get("db_pwd"):"null");
				String updateby_empName=(mp.get("updateby_empName")!=null?mp.get("updateby_empName"):"null");
				String live_status=(mp.get("live_status")!=null?mp.get("live_status"):"0");
				//addMap.put("live_status",Integer.toString(live_status));
				session=HibernateUtil.getSessionFactory().openSession();
				//session.clear();
				session.beginTransaction();
				server sr=new server();
				//sr.setServer_id(Integer.parseInt(sr));		
				sr.setDate_time(date_time);
				sr.setLocal_ip(local_ip);
				sr.setPublic_ip(public_ip);
				sr.setServer_model(server_model);
				sr.setServer_type(server_type);
				sr.setSerial_no(serial_no);
				sr.setOs(os);
				sr.setLocation(location);
				sr.setService(service);
				sr.setOwner(owner);
				sr.setServer_usr(server_usr);
				sr.setServer_pwd(server_pwd);
				sr.setDb_type(db_type);
				sr.setDb_usr(db_usr);
				sr.setDb_pwd(db_pwd);
				sr.setUpdateby_empName(updateby_empName);
				//sr.setLive_status(Integer.parseInt(live_status));
				sr.setLive_status(Integer.parseInt(live_status));
				session.save(sr);
				session.getTransaction().commit();
				session.flush();	
				System.out.println("[ ProcessReq#addServer()#DATE IS :"+date_time+" ]");
				retstr="success";
		}
		catch(Exception ex)
		{
			retstr="fail";
			System.out.println("[Exception#ProcessReq#addServer():"+ex+"]");
			ex.printStackTrace();
		}
		return retstr;		
	}
	public server checkServer(String serverIP,int ipType)
	{
		server ret_server=null; 
		try
		{
			
			Session session=null;
			Query qry=null;
			session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();			
			if(ipType==0)
			{	
				qry=session.createQuery("from server where local_ip="+serverIP);
			}
			else
			{
				qry=session.createQuery("from server where public_ip="+serverIP);
			}
			ret_server=(server)qry.uniqueResult();
			session.getTransaction().commit();
			
		}
		catch(Exception ex)
		{
			System.out.println("[Exception#ProcessReq#checkServer():"+ex+"]");
			ex.printStackTrace();
		}
		return ret_server;
	}
	public String updateServer(HashMap<String,String> mp)
	{
		//HashMap<String><String> mp
		//HashMap<K, V>
		String retstr=null;
		try
		{
				Session session=null;
	//int server_id;			
	//local_ip,public_ip,server_model,server_type,serial_no,os,location,service,
	//owner,server_usr,server_pwd,db_type,db_usr,db_pwd,updateby_empName
	//int live_status;			
				String server_id=mp.get("server_id");
				String public_ip=mp.get("public_ip");
				String server_model=mp.get("server_model");
				String server_type=mp.get("server_type");
				String serial_no=mp.get("serial_no");
				String os=mp.get("os");
				String location=mp.get("location");
				String service=mp.get("service");
				String owner=mp.get("owner");
				String server_usr=mp.get("server_usr");
				String server_pwd=mp.get("server_pwd");
				String db_type=mp.get("db_type");
				String db_usr=mp.get("db_usr");
				String db_pwd=mp.get("db_pwd");
				String updateby_empName=mp.get("updateby_empName");
				String live_status=mp.get("live_status");
				session=HibernateUtil.getSessionFactory().openSession();
				//session.beginTransaction();
				//session.openSession();
				//session.clear();
				session.beginTransaction();
				
				server sr=new server();				
				sr.setDate_time("date_time");
				sr.setServer_id(Integer.parseInt(server_id));
				sr.setPublic_ip(public_ip);
				sr.setServer_model(server_model);
				sr.setServer_type(server_type);
				sr.setSerial_no(serial_no);
				sr.setOs(os);
				sr.setLocation(location);
				sr.setService(service);
				sr.setOwner(owner);
				sr.setServer_usr(server_usr);
				sr.setServer_pwd(server_pwd);
				sr.setDb_type(db_type);
				sr.setDb_usr(db_usr);
				sr.setDb_pwd(db_pwd);
				sr.setUpdateby_empName(updateby_empName);
				sr.setLive_status(Integer.parseInt(live_status));
				session.save(sr);
				session.getTransaction().commit();
				session.flush();	
				retstr="success";
		}
		catch(Exception ex)
		{
			retstr="fail";
			System.out.println("[Exception#ProcessReq#updateServer():"+ex+"]");
			ex.printStackTrace();
		}
		return retstr;
	}
}
