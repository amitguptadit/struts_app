package com.ta.hibernate;

public class Constants {
enum status{SUCCESS,Fail};
}
