package com.ta.hibernate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity 
@Table(name="Entry_Set")
public class EntrySet {
	@Id 
	@GeneratedValue
	int eId;
	@ManyToOne
	Voucher vId;
	@ManyToOne
	EntryTypeDetails entryType;
	@ManyToOne
	AccountDetails particularId;
	
	float amount;

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public Voucher getvId() {
		return vId;
	}

	public void setvId(Voucher vId) {
		this.vId = vId;
	}

	public EntryTypeDetails getEntryType() {
		return entryType;
	}

	public void setEntryType(EntryTypeDetails entryType) {
		this.entryType = entryType;
	}

	public AccountDetails getParticularId() {
		return particularId;
	}

	public void setParticularId(AccountDetails particularId) {
		this.particularId = particularId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}
	

}
