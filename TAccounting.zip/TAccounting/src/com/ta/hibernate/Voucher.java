package com.ta.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity 
@Table(name="Tbl_Voucher")
public class Voucher {
@Id 
@GeneratedValue
int vId;
@ManyToOne
VoucherType vType;
float amount; 
String datetime;
int status;
String narration;
String notePad;

public String getNarration() {
	return narration;
}
public void setNarration(String narration) {
	this.narration = narration;
}
public String getNotePad() {
	return notePad;
}
public void setNotePad(String notePad) {
	this.notePad = notePad;
}
public VoucherType getvType() {
	return vType;
}
public void setvType(VoucherType vType) {
	this.vType = vType;
}
@Column(name="vId")
public int getvId() {
	return vId;
}
public void setvId(int vId) {
	this.vId = vId;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
public String getDatetime() {
	return datetime;
}
public void setDatetime(String datetime) {
	this.datetime = datetime;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}


}
