package com.ta.Actions;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.ActionSupport;
import com.ta.hibernate.VoucherType;
import com.ta.hibernate.utility.HibernateUtil;

public class VoucherDetailAction extends ActionSupport 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<VoucherType> voucherTypeList= new ArrayList<VoucherType>();
	
	 VoucherType voucherType=new VoucherType();
	 Session session = null;
     Transaction txn = null;

	 public String voucherList()
	 {
		session = HibernateUtil.getSessionFactory().openSession();
        txn = session.beginTransaction();
        List voucherList= new ArrayList();
        List<VoucherType> Ls=session.createQuery("from VoucherType where status=0").list();
                
        /*Iterator itr=Ls.iterator();
        while(itr.hasNext())
        {
        	voucherList.add((VoucherType)(itr.next()));
        }*/        
        for(VoucherType vType:Ls)
	    {
	    	voucherList.add(vType.getVtypeName());
	    }
        voucherTypeList=voucherList;
		session.getTransaction().commit();
		session.close();  
	    return "success";
	 }
	public VoucherType getVoucherType() {
		return voucherType;
	}


	public void setVoucherType(VoucherType voucherType)
	{
		this.voucherType = voucherType;
	}
	
	public List<VoucherType> getVoucherTypeList()
	{
		
		return voucherTypeList;
	}

	public void setVoucherTypeList(List<VoucherType> voucherTypeList)
	{
		this.voucherTypeList = voucherTypeList;
	}
	
}
